| `Version` | `Update Notes`                                                                                                                                           |
|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.0.5     | - Update ServerSync internally.                                                                                                                          |
| 1.0.4     | - Courtesy Update for Bog Witch. Just bumping the version and updating the last updated date. Nothing to see here.                                       |
| 1.0.3     | - Courtesy Update for Valheim 0.217.46. Just bumping the version and updating the last updated date. Nothing to see here.                                |
| 1.0.2     | - Update for Valheim 0.217.22                                                                                                                            |
| 1.0.1     | - Fix the yeet from happening when you're just trying to chat with your homies. There is a time and place for that. Sorry for involuntary yeet spageetz. |
| 1.0.0     | - Initial Release                                                                                                                                        |